#include "ssp.h"

int main(){
    double p = 0.5;
    SSP::Generator::generate("test_dfs.txt", 20, p, 1000); 
    SSP::Solver solverDFS("test_dfs.txt");
    solverDFS.solve();

    SSP::Generator::generate("test_dp_small.txt", 2000, p, 1000);
    SSP::Solver solverDP("test_dp_small.txt");
    solverDP.solve();

    SSP::Generator::generate("test_dp_heavy.txt", 200, p, 500000);
    SSP::Solver solverHeavy("test_dp_heavy.txt");
    solverHeavy.solve();

    SSP::Generator::generate("data_10k.txt", 10000, p, 10000000);
    SSP::Solver solverFallback("data_10k.txt");
    solverFallback.solve();
    std::cout << "\n";
    
    SSP::Generator::generate("data_100k.txt", 100000, p, 10000000);
    SSP::Solver solver100k("data_100k.txt");
    solver100k.solve();
    std::cout << "\n";

    SSP::Generator::generate("data_1m.txt", 1000000, p, 10000000);
    SSP::Solver solver1m("data_1m.txt");
    solver1m.solve();
    std::cout << "\n";

    SSP::Generator::generate("data_10m.txt", 10000000, p, 10000000);
    SSP::Solver solver10m("data_10m.txt");
    solver10m.solve();
    std::cout << "\n";

    return 0;
}