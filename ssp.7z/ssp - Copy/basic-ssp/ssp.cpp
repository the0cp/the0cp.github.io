#include <chrono>
#include <cmath>
#include <cstring>
#include <numeric>
#include <fstream>
#include <random>

#include <sys/resource.h>
#include <unistd.h>

#include "ssp.h"

namespace SSP {

    // ==========================================
    // BigInt Implementation
    // ==========================================

    BigInt::BigInt(int64_t v){
        if(v == 0)  chunks.push_back(0);
        while(v > 0){
            chunks.push_back(v % BASE);
            v /= BASE;
        }
    }

    BigInt& BigInt::operator+=(const BigInt& other){
        int64_t carry = 0;
        for(size_t i = 0; i < other.chunks.size() || carry; ++i){
            if(i == chunks.size()) chunks.push_back(0);
            
            int64_t current = chunks[i] + carry + (i < other.chunks.size() ? other.chunks[i] : 0);
            chunks[i] = current % BASE;
            carry = current / BASE;
        }
        return *this;
    }

    int64_t BigInt::toTarget(double p) const {
        long double d_sum = 0;
        long double scale = 1.0;
        
        for(auto c : chunks){
            d_sum += (long double)c * scale;
            scale *= 1e9;
        }

        return (int64_t)(d_sum * p); 
    }

    std::ostream& operator<<(std::ostream& os, const BigInt& bi){
        if(bi.chunks.empty()){ 
            return os << 0; 
        }
        os << bi.chunks.back();
        for(int i = (int)bi.chunks.size() - 2; i >= 0; i--){
            os << std::setw(9) << std::setfill('0') << bi.chunks[i];
        }
        return os;
    }

    // ==========================================
    // RadixSortor Implementation
    // ==========================================

    void RadixSortor::sort(std::vector<Item>& items){
        int n = items.size();
        std::vector<Item>output(n);

        for(int shift = 0; shift < 64; shift += 8){
            int count[256] = {0};
            for(auto& x : items){
                count[(x.value >> shift) & 0xff]++;
            }
            for(int i = 254; i>=0; i--){
                count[i] += count[i + 1];
            }
            for(int i = n - 1; i >= 0; i--){
                output[--count[(items[i].value >> shift) & 0xff]] = items[i];
            }
            items = output;
        }
    }


    // ==========================================
    // Generator Implementation
    // ==========================================

    void Generator::generate(const std::string& filename, size_t n, double p, int max_val){
        std::ofstream file(filename);
        if(!file.is_open()){
            std::cerr << "Cannot open file: " << filename << std::endl;
            return;
        }

        std::random_device rd;
        std::mt19937_64 gen(rd());  // 64-bit Mersenne Twister engine
        std::uniform_int_distribution<int64_t> dis(1, max_val);

        std::vector<ValueType>buffer;
        buffer.reserve(n);

        BigInt sum(0);
        for(size_t i = 0; i < n; i++){
            ValueType v = dis(gen);
            buffer.push_back(v);
            sum += BigInt(v);
        }

        int64_t target = sum.toTarget(p);

        file << n << "\n";
        file << target << "\n";
        for(size_t i = 0; i < n; i++){
            file << buffer[i] << (i == n - 1 ? "" : " ");
        }

        file.close();
    }


    // ==========================================
    // Solver Implementation
    // ==========================================

    Solver::Solver(const std::string& filename) : target(0), n(0){
        load(filename);
    }

    void Solver::load(const std::string& filename){
        std::ifstream file(filename);
        if(!file.is_open()){
            std::cerr << "Cannot open file: " << filename << std::endl;
            return;
        }

        file >> n >> target;
        items.resize(n);

        for(size_t i = 0; i < n; i++){
            ValueType v;
            file >> v;
            items[i] = {v, static_cast<IndexType>(i)};
        }

        RadixSortor::sort(items);
    }

    void Solver::out(const std::vector<ValueType>& result){
        std::cout << "[Solution]" << std::endl;
        std::cout << "Subset Size: " << result.size() << std::endl;
        
        int64_t sum = 0;
        for(auto v : result) sum += v;
        
        
        std::cout << std::endl;
        
        std::cout << "Items: ";
        size_t limit = 20;
        for(size_t i=0; i < std::min(result.size(), limit); ++i){
            std::cout << result[i] << " ";
        }
        if(result.size() > limit){
            std::cout << "... (" << (result.size() - limit) << " more)";
        }
        std::cout << std::endl;
    }

    bool Solver::dfs(size_t index, int64_t curSum, std::vector<ValueType>& curSelec){
        if(curSum == target){
            return true;
        }

        if(index >= n || curSum > target){
            return false;
        }

        curSelec.push_back(items[index].value);
        if(dfs(index + 1, curSum + items[index].value, curSelec)){
            return true;
        }
        curSelec.pop_back();    // backtrack

        if(dfs(index + 1, curSum, curSelec)){
            return true;
        }

        return false;
    }

    bool Solver::dp(std::vector<ValueType>& result){
        std::vector<int32_t>dp(target + 1, -2); // -2 means unreachable
        dp[0] = -1; // base case

        for(size_t i = 0; i < n; i++){
            int64_t val = items[i].value;
            if(val > target) continue;

            for(size_t w = target; w >= val; w--){
                if(dp[w - val] != -2 && dp[w] == -2){
                    dp[w] = static_cast<int32_t>(i);
                }
            }
        }

        if(dp[target] == -2){
            return false;   // no solution
        }

        result.clear();
        size_t cur = target;
        while(cur > 0){
            int32_t idx = dp[cur];
            if(idx < 0) break;
            result.push_back(items[idx].value);
            cur -= items[idx].value;
        }

        return true;
    }

    bool Solver::greedy(const std::vector<Item>& items, std::vector<ValueType>& result){
        int64_t curSum = 0;
        result.clear();

        for(const auto& item : items){
            if(curSum + item.value <= target){
                curSum += item.value;
                result.push_back(item.value);
            }
            if(curSum == target){
                return true;
            }
        }
        return false;
    }

    bool Solver::randomized(std::vector<ValueType>& result){
        std::vector<Item>work_items = items;
        RadixSortor::sort(work_items);

        if(greedy(work_items, result)){
            return true;
        }

        std::mt19937_64 rng(std::random_device{}());
        std::cout << "[Info] Sorted greedy failed. Starting " << MAX_RETRY << " random retries..." << std::endl;

        for(size_t i = 0; i < MAX_RETRY; i++){
            std::shuffle(work_items.begin(), work_items.end(), rng);
            
            if(greedy(work_items, result)){
                std::cout << "  -> Solved at retry " << (i + 1) << std::endl;
                return true;
            }
        }

        return false;
    }

    void Solver::solve(){
        Profiler prof("Solver Total");
        prof.start();

        std::vector<ValueType> result;
        bool found = false;

        std::cout << "Solving for N = " << n << ", Target = " << target << "..." << std::endl;

        if(n <= THRESHOLD_SMALL){
            std::cout << "[Strategy] Using DFS..." << std::endl;
            found = dfs(0, 0, result);
        }else if(n <= THRESHOLD_MEDIUM){
            double estimatedOps = (double)n * target;
            
            const double MAX_DP_OPS = 10000000000.0; 
            const int64_t MAX_DP_MEMORY = 100000000;
            if(estimatedOps <= MAX_DP_OPS && target <= MAX_DP_MEMORY){
                std::cout << "[Strategy] Using DP..." << std::endl;

                try{
                    found = dp(result);
                }catch(const std::bad_alloc& e){
                    std::cerr << "[Error] Memory allocation failed" << std::endl;
                    std::cout << "[Strategy] Falling back to Randomized Greedy..." << std::endl;
                    found = randomized(result);
                }
            }else{
                std::cout << "Falling back to Greedy..." << std::endl;
                found = randomized(result);
            }
        }else{
            std::cout << "[Strategy] Using Randomized Greedy..." << std::endl;
            found = randomized(result);
        }

        prof.stop();
        
        if(found){
            std::cout << "[Result] Solution Found!" << std::endl;
            prof.report(n);
            out(result);
        }else{
            prof.report(n);
            std::cout << "[Result] No Solution Found." << std::endl;
        }
    }

    Profiler::Profiler(const std::string& name) : name(name) {}

    void Profiler::start(){
        startTime = std::chrono::high_resolution_clock::now();
    }

    void Profiler::stop(){
        endTime = std::chrono::high_resolution_clock::now();
    }

    double Profiler::getMemMB(){
        struct rusage usage;
        getrusage(RUSAGE_SELF, &usage);
        return static_cast<double>(usage.ru_maxrss) / 1024.0; // Convert to MB
    }

    void Profiler::report(size_t dataSize){
        std::chrono::duration<double> elapsed = endTime - startTime;
        double memMB = getMemMB();

        std::cout << "[" << name << " Profiling] Time: " << elapsed.count() << " seconds";
        if(dataSize > 0){
            double throughput = static_cast<double>(dataSize) / elapsed.count();
            std::cout << ", Throughput: " << throughput << " ops/s";
        }
        std::cout << ", Memory Usage: " << memMB << " MB" << std::endl;
    }

} // namespace SSP
