#include <chrono>
#include <cmath>
#include <cstring>
#include <numeric>
#include <fstream>
#include <random>

#include <sys/resource.h>
#include <unistd.h>

#include "knapsack.h"

namespace KNAP {

    // ==========================================
    // BigInt Implementation
    // ==========================================

    BigInt::BigInt(int64_t v){
        if(v == 0)  chunks.push_back(0);
        while(v > 0){
            chunks.push_back(v % BASE);
            v /= BASE;
        }
    }

    BigInt& BigInt::operator+=(const BigInt& other){
        int64_t carry = 0;
        for(size_t i = 0; i < other.chunks.size() || carry; ++i){
            if(i == chunks.size()) chunks.push_back(0);
            
            int64_t current = chunks[i] + carry + (i < other.chunks.size() ? other.chunks[i] : 0);
            chunks[i] = current % BASE;
            carry = current / BASE;
        }
        return *this;
    }

    int64_t BigInt::toTarget(double p) const {
        long double d_sum = 0;
        long double scale = 1.0;
        
        for(auto c : chunks){
            d_sum += (long double)c * scale;
            scale *= 1e9;
        }

        return (int64_t)(d_sum * p); 
    }

    std::ostream& operator<<(std::ostream& os, const BigInt& bi){
        if(bi.chunks.empty()){ 
            return os << 0; 
        }
        os << bi.chunks.back();
        for(int i = (int)bi.chunks.size() - 2; i >= 0; i--){
            os << std::setw(9) << std::setfill('0') << bi.chunks[i];
        }
        return os;
    }

    // ==========================================
    // RadixSortor Implementation
    // ==========================================

    void RadixSortor::sort(std::vector<Item>& items){
        int n = items.size();
        std::vector<Item>output(n);

        for(int shift = 0; shift < 64; shift += 8){
            int count[256] = {0};
            for(auto& x : items){
                count[(x.value >> shift) & 0xff]++;
            }
            for(int i = 1; i < 256; i++){
                count[i] += count[i - 1];
            }
            for(int i = n - 1; i >= 0; i--){
                output[--count[(items[i].value >> shift) & 0xff]] = items[i];
            }
            items = output;
        }
    }


    // ==========================================
    // Generator Implementation
    // ==========================================

    void Generator::generate(const std::string& filename, size_t n, double p, int max_val){
        std::ofstream file(filename);
        if(!file.is_open()){
            std::cerr << "Cannot open file: " << filename << std::endl;
            return;
        }

        std::random_device rd;
        std::mt19937_64 gen(rd());  // 64-bit Mersenne Twister engine
        std::uniform_int_distribution<int64_t> dis(1, max_val);

        std::vector<ValueType>buffer;
        buffer.reserve(n);

        BigInt sum(0);
        for(size_t i = 0; i < n; i++){
            ValueType v = dis(gen);
            buffer.push_back(v);
            sum += BigInt(v);
        }

        int64_t target = sum.toTarget(p);

        file << n << "\n";
        file << target << "\n";
        for(size_t i = 0; i < n; i++){
            file << buffer[i] << (i == n - 1 ? "" : " ");
        }

        file.close();
    }


    // ==========================================
    // Solver Implementation
    // ==========================================

    Solver::Solver(const std::string& filename) : target(0), n(0){
        load(filename);
    }

    void Solver::load(const std::string& filename){
        std::ifstream file(filename);
        if(!file.is_open()){
            std::cerr << "Cannot open file: " << filename << std::endl;
            return;
        }

        file >> n >> target;
        items.resize(n);

        for(size_t i = 0; i < n; i++){
            ValueType v;
            file >> v;
            items[i] = {v, static_cast<IndexType>(i)};
        }

        RadixSortor::sort(items);
    }

    void Solver::out(const std::vector<ValueType>& result){
        std::cout << "[Solution]" << std::endl;
        std::cout << "Subset Size: " << result.size() << std::endl;
        
        int64_t sum = 0;
        for(auto v : result) sum += v;
        
        
        std::cout << std::endl;
        
        std::cout << "Items: ";
        size_t limit = 20;
        for(size_t i=0; i < std::min(result.size(), limit); ++i){
            std::cout << result[i] << " ";
        }
        if(result.size() > limit){
            std::cout << "... (" << (result.size() - limit) << " more)";
        }
        std::cout << std::endl;
    }

    bool Solver::dfs(size_t index, int64_t curSum, std::vector<ValueType>& curSelec, std::vector<ValueType>& bestSelec){
        if(curSum == target){
            if(curSelec.size() > bestSelec.size()){
            bestSelec = curSelec;
            }
            return true;
        }

        if(index >= n || curSum > target){
            return false;
        }

        if(curSelec.size() + (n - index) <= bestSelec.size()){
            return false;
        }

        bool res = false;

        curSelec.push_back(items[index].value);
        if(dfs(index + 1, curSum + items[index].value, curSelec, bestSelec)){
            res = true;
        }
        curSelec.pop_back();

        if(dfs(index + 1, curSum, curSelec, bestSelec)){
            res = true;
        }

        return res;
    }

    bool Solver::dp(std::vector<ValueType>& result){
        std::vector<int32_t>dp(target + 1, -1); // -1 means unreachable
        std::vector<int32_t>from(target + 1, -1);
        dp[0] = 0; // base case

        for(size_t i = 0; i < n; i++){
            int64_t val = items[i].value;
            if(val > target) break;

            for(size_t w = target; w >= val; w--){
                if(dp[w - val] != -1 && dp[w - val] + 1 > dp[w]){
                    dp[w] = dp[w - val] + 1;
                    from[w] = static_cast<int32_t>(i);
                }
            }
        }

        if(dp[target] == -1){
            return false;   // no solution
        }

        // reconstruction
        result.clear();
        size_t cur = target;
        while(cur > 0){
            int32_t idx = from[cur];
            if(idx < 0) break;
            result.push_back(items[idx].value);
            cur -= items[idx].value;
        }

        return true;
    }

    bool Solver::greedy(std::vector<ValueType>& result){
        std::mt19937 rng(std::random_device{}());
        int MAX_ATTEMPT = (n < 1000000) ? 2000 : 10;
        std::vector<int> blacklist;

        for(int i = 0; i < MAX_ATTEMPT; i++){
            int64_t curSum = 0;
            int boundary = 0;
            std::vector<int> curSelec;
            curSelec.reserve(n);

            std::vector<bool> isBanned(n, false);
            for(int idx : blacklist) isBanned[idx] = true;

            for(int j = 0; j < n; j++){
                if(isBanned[j]) continue;

                if(curSum + items[j].value <= target){
                    curSum += items[j].value;
                    curSelec.push_back(j);
                }else{
                    boundary = j;
                    break;
                }
            }

            if(curSum == target){
                result.clear();
                for(int idx : curSelec) result.push_back(items[idx].value);
                return true;
            }

            int64_t gap = target - curSum;
            int64_t minValOut = items[boundary].value - gap;
            int64_t maxValOut = items.back().value - gap;

            auto itSelBegin = curSelec.begin();
            auto itSelEnd = curSelec.end();

            auto itSearchStart = std::lower_bound(itSelBegin, itSelEnd, minValOut, [&](int idx, int64_t val){
                return items[idx].value < val;
            });

            auto itSearchEnd = std::upper_bound(itSelBegin, itSelEnd, maxValOut, [&](int64_t val, int idx){
                return val < items[idx].value;
            });

            int checks = 0;
            const int MAX_CHECKS = 10000;

            auto itCand = itSearchEnd;
            while(itCand != itSearchStart){
                --itCand;
                if(++checks > MAX_CHECKS) break;

                int idxOut = *itCand;
                int64_t valOut = items[idxOut].value;
                int64_t valIn = valOut + gap;

                Item key = {valIn, 0};
                auto itIn = std::lower_bound(items.begin(), items.end(), key, [](const Item& a, const Item& b){
                    return a.value < b.value;
                });

                if(itIn != items.end() && itIn->value == valIn){
                     if(itIn - items.begin() > curSelec.back()){
                        result.clear();
                        result.reserve(curSelec.size());

                        for(int selIdx : curSelec){
                            if(selIdx != idxOut){
                                result.push_back(items[selIdx].value);
                            }
                        }
                        result.push_back(itIn->value);
                        return true;
                     }
                }
            }

            if(i < MAX_ATTEMPT - 1){
                blacklist.clear();
                std::uniform_int_distribution<int> distCount(1, 3);
                int banCount = distCount(rng);

                if(!curSelec.empty()){
                    std::uniform_int_distribution<int> distIdx(std::max(0, (int)curSelec.size() - 500), (int)curSelec.size() - 1);

                    for(int k = 0; k < banCount; k++){
                        int randPos = distIdx(rng);
                        blacklist.push_back(curSelec[randPos]);
                    }
                }
            }
        }

        return false;
    }

    void Solver::solve(){
        Profiler prof("Solver Total");
        prof.start();

        std::vector<ValueType> result;
        
        bool found = false;

        std::cout << "Solving for N = " << n << ", Target = " << target << "..." << std::endl;

        if(n <= THRESHOLD_SMALL){
            std::cout << "[Strategy] Using DFS..." << std::endl;
            std::vector<ValueType> curSelec;
            std::vector<ValueType> bestSelec;
            
            dfs(0, 0, curSelec, bestSelec);
            if(!bestSelec.empty()){
                found = true;
                result = bestSelec;
            }else{
                found = false;
            }
        }else if(n <= THRESHOLD_MEDIUM){
            double estimatedOps = (double)n * target;
            
            const double MAX_DP_OPS = 10000000000.0; 
            const int64_t MAX_DP_MEMORY = 100000000;
            if(estimatedOps <= MAX_DP_OPS && target <= MAX_DP_MEMORY){
                std::cout << "[Strategy] Using DP..." << std::endl;

                try{
                    found = dp(result);
                }catch(const std::bad_alloc& e){
                    std::cerr << "[Error] Memory allocation failed" << std::endl;
                    std::cout << "[Strategy] Falling back to Randomized Greedy..." << std::endl;
                    found = greedy(result);
                }
            }else{
                std::cout << "Falling back to Greedy..." << std::endl;
                found = greedy(result);
            }
        }else{
            std::cout << "[Strategy] Using Randomized Greedy..." << std::endl;
            found = greedy(result);
        }

        prof.stop();
        
        if(found){
            std::cout << "[Result] Solution Found!" << std::endl;
            prof.report(n);
            out(result);
        }else{
            prof.report(n);
            std::cout << "[Result] No Solution Found." << std::endl;
        }
    }

    Profiler::Profiler(const std::string& name) : name(name) {}

    void Profiler::start(){
        startTime = std::chrono::high_resolution_clock::now();
    }

    void Profiler::stop(){
        endTime = std::chrono::high_resolution_clock::now();
    }

    double Profiler::getMemMB(){
        struct rusage usage;
        getrusage(RUSAGE_SELF, &usage);
        return static_cast<double>(usage.ru_maxrss) / 1024.0; // Convert to MB
    }

    void Profiler::report(size_t dataSize){
        std::chrono::duration<double> elapsed = endTime - startTime;
        double memMB = getMemMB();

        std::cout << "[" << name << " Profiling] Time: " << elapsed.count() << " seconds";
        if(dataSize > 0){
            double throughput = static_cast<double>(dataSize) / elapsed.count();
            std::cout << ", Throughput: " << throughput << " ops/s";
        }
        std::cout << ", Memory Usage: " << memMB << " MB" << std::endl;
    }

} // namespace KNAP
