#include "knapsack.h"

int main(){
    double p = 0.5;

    KNAP::Generator::generate("data_10k.txt", 10000, p, 10000);
    KNAP::Solver solverFallback("data_10k.txt");
    solverFallback.solve();
    std::cout << "\n";
    
    KNAP::Generator::generate("data_100k.txt", 100000, p, 100000);
    KNAP::Solver solver100k("data_100k.txt");
    solver100k.solve();
    std::cout << "\n";

    KNAP::Generator::generate("data_1m.txt", 1000000, p, 1000000);
    KNAP::Solver solver1m("data_1m.txt");
    solver1m.solve();
    std::cout << "\n";

    KNAP::Generator::generate("data_10m.txt", 10000000, p, 10000000);
    KNAP::Solver solver10m("data_10m.txt");
    solver10m.solve();
    std::cout << "\n";

    return 0;
}