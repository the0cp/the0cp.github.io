#pragma once

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdint>
#include <algorithm>
#include <random>
#include <iomanip>
#include <compare>
#include <chrono>

namespace KNAP{
    using ValueType = int64_t; 
    using IndexType = int32_t;

    struct Item{
        ValueType value;
        ValueType weight;
        uint64_t sortKey;
        IndexType id;
    };

    class BigInt{
    private:
        static const int BASE = 1e9;
        std::vector<int64_t>chunks;

    public:
        BigInt(int64_t v = 0);

        // override operators for better calculation
        BigInt& operator+=(const BigInt& other);

        int64_t toTarget(double p) const;

        friend std::ostream& operator<<(std::ostream& os, const BigInt& bi);
    };

    class RadixSortor{
    public:
        static void sort(std::vector<Item>& items);
    };

    class Generator{
    public:
        static void generate(const std::string& filename, size_t n, double p, int max_val = 1e7);
    };

    class Solver{
    private:
        std::vector<Item>items;
        std::vector<int64_t> suffix;
        int64_t target;
        size_t n;
        int split = -1;

        static const size_t THRESHOLD_SMALL = 40;
        static const size_t THRESHOLD_MEDIUM = 10000;
        static const size_t MAX_RETRY = 1000;

        void load(const std::string& filename);
        bool dfs(size_t index, int64_t curW, int64_t curV, std::vector<ValueType>& curSelec, std::vector<ValueType>& bestSelec, int64_t& bestVal);
        bool dp(std::vector<ValueType>& result);
        void findSplit();
        bool greedy(std::vector<ValueType>& result);
        void out(const std::vector<ValueType>& result);
    
    public:
        Solver(const std::string& filename);
        void solve();
    };

    class Profiler{
    private:
        std::string name;
        std::chrono::high_resolution_clock::time_point startTime;
        std::chrono::high_resolution_clock::time_point endTime;
        double getMemMB();
    
    public:
        Profiler(const std::string& name = "Task");
        void start();
        void stop();
        void report(size_t dataSize = 0);
    };
};